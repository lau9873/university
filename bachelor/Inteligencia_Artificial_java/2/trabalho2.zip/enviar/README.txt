Como testar o nosso projeto:

$ javac IA02.java

$ java IA02

Qual o algoritmo a usar?
MINMAX=0; ALPHABETA=1; MCTS=2

*escolher a op��o adequada*

Prefere jogar primeiro?
SIM=1; NAO=0

*escolher a op��o adequada*

*prosseguir com o jogo*


Para efetuar uma jogada escreve-se o n�mero da coluna
onde se pretende colocar a pe�a, estando as colunas
numeradas de 0 a 6, tal como indicado acima do tabuleiro.
No caso de querer mudar a constante c, basta ir � classe
MCnode no m�todo getUCB().
